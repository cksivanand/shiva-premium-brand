'use client';

import React, { useState, useEffect, useRef } from 'react';
import { ChevronDown, Zap, Globe, TrendingUp, Leaf, Code, Mail, Linkedin, Instagram, Github, Twitter } from 'lucide-react';

export default function SivaPremiumBrand() {
  const [scrollY, setScrollY] = useState(0);
  const [activeSubtitle, setActiveSubtitle] = useState(0);
  const [portfolioValue, setPortfolioValue] = useState(324500);
  const [particles, setParticles] = useState([]);

  const subtitles = [
    "Ecosystem Services Student",
    "Forex Trader",
    "Crypto Trader",
    "Startup Founder",
    "Future Global Entrepreneur"
  ];

  // Scroll listener
  useEffect(() => {
    const handleScroll = () => setScrollY(window.scrollY);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Subtitle rotation
  useEffect(() => {
    const timer = setInterval(() => {
      setActiveSubtitle((prev) => (prev + 1) % subtitles.length);
    }, 3000);
    return () => clearInterval(timer);
  }, []);

  // Portfolio animation
  useEffect(() => {
    const timer = setInterval(() => {
      setPortfolioValue((prev) => prev + Math.random() * 2500 - 1000);
    }, 2000);
    return () => clearInterval(timer);
  }, []);

  // Floating particles effect
  useEffect(() => {
    const generateParticles = () => {
      return Array.from({ length: 50 }).map(() => ({
        id: Math.random(),
        x: Math.random() * 100,
        y: Math.random() * 100,
        size: Math.random() * 2 + 1,
        opacity: Math.random() * 0.5 + 0.1,
        duration: Math.random() * 20 + 20,
      }));
    };
    setParticles(generateParticles());
  }, []);

  return (
    <div className="relative w-full min-h-screen bg-black overflow-hidden">
      {/* Premium gradient background */}
      <div className="fixed inset-0 z-0">
        <div className="absolute inset-0 bg-gradient-to-br from-black via-slate-950 to-black" />
        <div className="absolute top-0 right-0 w-96 h-96 bg-emerald-900/20 rounded-full blur-3xl opacity-30" />
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-slate-800/20 rounded-full blur-3xl opacity-20" />
      </div>

      {/* Floating particles */}
      <div className="fixed inset-0 z-0 overflow-hidden">
        {particles.map((particle) => (
          <div
            key={particle.id}
            className="absolute rounded-full bg-emerald-400"
            style={{
              left: `${particle.x}%`,
              top: `${particle.y}%`,
              width: `${particle.size}px`,
              height: `${particle.size}px`,
              opacity: particle.opacity,
              animation: `float ${particle.duration}s infinite ease-in-out`,
            }}
          />
        ))}
      </div>

      {/* Content wrapper */}
      <div className="relative z-10">
        {/* ===== HERO SECTION ===== */}
        <section className="h-screen flex flex-col justify-center items-center px-6 relative overflow-hidden">
          {/* Animated background lines */}
          <div className="absolute inset-0 overflow-hidden">
            {[...Array(5)].map((_, i) => (
              <div
                key={i}
                className="absolute h-px bg-gradient-to-r from-transparent via-emerald-500/20 to-transparent"
                style={{
                  top: `${20 + i * 15}%`,
                  width: '200%',
                  animation: `scan 8s linear infinite`,
                  animationDelay: `${i * 1.6}s`,
                }}
              />
            ))}
          </div>

          <div className="text-center space-y-8 animate-fade-in">
            {/* Name with glow */}
            <div className="relative">
              <h1 className="text-7xl md:text-8xl font-black text-white tracking-tighter relative z-10">
                SIVANAND
              </h1>
              <p className="text-xl md:text-2xl text-emerald-300 font-light mt-2">C K</p>
              <div className="absolute -inset-12 bg-gradient-to-r from-emerald-500/10 to-transparent blur-3xl -z-10" />
            </div>

            {/* Animated subtitle */}
            <div className="relative h-12 flex items-center justify-center">
              <div className="relative text-xl md:text-2xl h-8 flex items-center">
                <span
                  className="absolute text-emerald-400 font-light transition-all duration-500"
                  style={{
                    opacity: 1,
                    animation: 'fadeInOut 3s infinite',
                  }}
                >
                  {subtitles[activeSubtitle]}
                </span>
              </div>
            </div>

            {/* Power statement */}
            <p className="text-lg text-gray-300 max-w-2xl mx-auto font-light leading-relaxed">
              Building wealth, ecosystems, and the future simultaneously.
            </p>

            {/* CTA Button */}
            <div className="pt-6">
              <button className="px-8 py-3 bg-emerald-600 hover:bg-emerald-500 text-black font-semibold rounded-lg transition-all duration-300 transform hover:scale-105 flex items-center gap-2 mx-auto">
                Explore My World
                <ChevronDown className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Scroll indicator */}
          <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
            <div className="w-6 h-10 border-2 border-emerald-400/50 rounded-full flex justify-center p-2">
              <div className="w-1 h-2 bg-emerald-400 rounded-full animate-pulse" />
            </div>
          </div>
        </section>

        {/* ===== TRADER IDENTITY SECTION ===== */}
        <section className="min-h-screen bg-gradient-to-b from-slate-950 to-black py-20 px-6 relative">
          <div className="max-w-6xl mx-auto">
            <h2 className="text-5xl md:text-6xl font-black text-white mb-16 text-center">
              TRADER'S MINDSET
            </h2>

            <div className="grid md:grid-cols-2 gap-8 mb-16">
              {/* Portfolio visualization */}
              <div className="bg-gradient-to-br from-slate-900 to-slate-950 border border-emerald-500/20 rounded-2xl p-8 backdrop-blur-sm hover:border-emerald-500/40 transition-all duration-500">
                <div className="flex justify-between items-start mb-8">
                  <div>
                    <p className="text-emerald-400 text-sm font-mono">TOTAL PORTFOLIO</p>
                    <p className="text-4xl font-bold text-white mt-2">
                      ${(portfolioValue / 1000).toFixed(1)}K
                    </p>
                  </div>
                  <TrendingUp className="w-8 h-8 text-emerald-400" />
                </div>

                {/* Mini chart simulation */}
                <div className="relative h-32 mb-6">
                  <svg className="w-full h-full" viewBox="0 0 200 100" preserveAspectRatio="none">
                    <polyline
                      points="0,70 20,65 40,75 60,50 80,55 100,30 120,40 140,25 160,35 180,20 200,15"
                      fill="none"
                      stroke="url(#gradient)"
                      strokeWidth="2"
                    />
                    <defs>
                      <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="0%">
                        <stop offset="0%" stopColor="#34d399" stopOpacity="0.3" />
                        <stop offset="100%" stopColor="#34d399" stopOpacity="0.8" />
                      </linearGradient>
                    </defs>
                  </svg>
                </div>

                <p className="text-emerald-300 text-sm">
                  +12.4% This Month | YTD: +48.2%
                </p>
              </div>

              {/* Mindset traits */}
              <div className="space-y-4">
                {['Patience', 'Precision', 'Consistency', 'Long-term Vision'].map((trait, idx) => (
                  <div
                    key={idx}
                    className="bg-emerald-900/10 border border-emerald-500/30 rounded-xl p-6 hover:bg-emerald-900/20 transition-all duration-300 transform hover:translate-x-2"
                  >
                    <p className="text-emerald-400 font-bold text-lg flex items-center gap-2">
                      <Zap className="w-5 h-5" />
                      {trait}
                    </p>
                    <p className="text-gray-400 text-sm mt-2">
                      {trait === 'Patience' && 'Waiting for the perfect setup, not chasing'}
                      {trait === 'Precision' && 'Risk management is sacred, emotions are eliminated'}
                      {trait === 'Consistency' && 'Small wins compound into extraordinary wealth'}
                      {trait === 'Long-term Vision' && 'Building generational wealth, not quick gains'}
                    </p>
                  </div>
                ))}
              </div>
            </div>

            {/* Market Psychology */}
            <div className="bg-black border border-emerald-500/20 rounded-2xl p-8 border-l-4 border-l-emerald-500">
              <p className="text-emerald-300 text-sm font-mono mb-2">MARKET PSYCHOLOGY</p>
              <p className="text-white text-lg font-light">
                "The market doesn't reward the smartest. It rewards the most disciplined. 
                Every trade is a lesson in human psychology. Every loss is tuition paid for 
                understanding how fear and greed move the markets."
              </p>
            </div>
          </div>
        </section>

        {/* ===== ECOXCHANGE FOUNDER SECTION ===== */}
        <section className="min-h-screen bg-gradient-to-b from-black to-slate-950 py-20 px-6 relative">
          <div className="max-w-6xl mx-auto">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-2 h-2 bg-emerald-400 rounded-full animate-pulse" />
              <p className="text-emerald-400 text-sm font-mono">EARLY STAGE FOUNDER</p>
            </div>

            <h2 className="text-5xl md:text-6xl font-black text-white mb-12">
              EcoXchange
            </h2>

            <div className="grid md:grid-cols-2 gap-12 mb-12">
              {/* Left: Vision */}
              <div className="space-y-6">
                <p className="text-xl text-gray-300 leading-relaxed">
                  A <span className="text-emerald-400 font-bold">next-generation platform</span> connecting ecosystem restoration, sustainability, farmers, AI monitoring, and carbon-driven environmental solutions.
                </p>

                <div className="space-y-3">
                  <p className="text-emerald-300 font-semibold">Building at the intersection of:</p>
                  {['Climate Tech', 'Sustainable Finance', 'Agricultural Innovation', 'Ecosystem Intelligence'].map((item, idx) => (
                    <div key={idx} className="flex items-center gap-2 text-gray-300">
                      <div className="w-2 h-2 bg-emerald-400 rounded-full" />
                      {item}
                    </div>
                  ))}
                </div>

                <button className="px-6 py-2 bg-emerald-600/20 border border-emerald-500/50 text-emerald-300 rounded-lg hover:bg-emerald-600/30 transition-all duration-300">
                  Learn More
                </button>
              </div>

              {/* Right: Animated ecosystem visualization */}
              <div className="relative h-80 bg-gradient-to-br from-emerald-900/10 to-slate-900/10 rounded-2xl border border-emerald-500/20 overflow-hidden flex items-center justify-center">
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="relative w-64 h-64">
                    {/* Rotating outer ring */}
                    <div
                      className="absolute inset-0 border-2 border-emerald-500/30 rounded-full"
                      style={{ animation: 'rotate 20s linear infinite' }}
                    />
                    {/* Middle ring */}
                    <div
                      className="absolute inset-4 border border-emerald-400/20 rounded-full"
                      style={{ animation: 'rotate 30s linear infinite reverse' }}
                    />
                    {/* Center circle */}
                    <div className="absolute inset-20 bg-gradient-to-br from-emerald-500/20 to-slate-700/20 rounded-full flex items-center justify-center border border-emerald-400/40">
                      <Globe className="w-16 h-16 text-emerald-400 opacity-60" />
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Roadmap */}
            <div className="bg-slate-900/30 border border-emerald-500/20 rounded-2xl p-8 overflow-x-auto">
              <p className="text-emerald-300 text-sm font-mono mb-6">STARTUP ROADMAP</p>
              <div className="flex gap-4 min-w-max">
                {['MVP', 'Farmer Network', 'AI Monitoring', 'Carbon Credits', 'Series A'].map((phase, idx) => (
                  <div
                    key={idx}
                    className="px-6 py-3 bg-emerald-900/20 border border-emerald-500/30 rounded-lg text-emerald-300 font-semibold whitespace-nowrap"
                  >
                    {phase}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* ===== ABOUT ME SECTION ===== */}
        <section className="min-h-screen bg-gradient-to-b from-slate-950 to-black py-20 px-6">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-5xl md:text-6xl font-black text-white mb-12 text-center">
              About Me
            </h2>

            <div className="space-y-8">
              {/* Story segments */}
              {[
                {
                  title: "Agriculture to Ambition",
                  text: "Bachelor's in Agriculture from Hemvati Nandan Bahuguna Garhwal University, Dehradun. From understanding soil and crops to understanding markets and systems."
                },
                {
                  title: "Germany, Global Vision",
                  text: "Master's in Ecosystem Services at TU Dresden. Studying the intersection of environment, economy, and innovation in Europe's heart."
                },
                {
                  title: "Finance × Sustainability",
                  text: "Passionate about using finance as a tool for environmental restoration. Forex and crypto trading not just for wealth, but to understand global capital flows and innovation."
                },
                {
                  title: "The Accident That Changed Everything",
                  text: "December 2022 tested my resilience. It revealed who truly stands by you and deepened my commitment to building something meaningful for my family and the world."
                },
                {
                  title: "Vision for Tomorrow",
                  text: "Flying parents to Germany in business class. Building companies that matter. Creating wealth that funds conservation. Proving that ambition and ethics aren't mutually exclusive."
                }
              ].map((item, idx) => (
                <div
                  key={idx}
                  className="bg-emerald-900/5 border border-emerald-500/20 rounded-xl p-8 hover:border-emerald-500/40 transition-all duration-300"
                  style={{
                    animation: `fadeInUp 0.6s ease-out ${idx * 0.1}s both`,
                  }}
                >
                  <h3 className="text-emerald-400 font-bold text-lg mb-3">{item.title}</h3>
                  <p className="text-gray-300 leading-relaxed text-lg">{item.text}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* ===== CURRENTLY BUILDING SECTION ===== */}
        <section className="min-h-screen bg-gradient-to-b from-black to-slate-950 py-20 px-6">
          <div className="max-w-6xl mx-auto">
            <h2 className="text-5xl md:text-6xl font-black text-white mb-12 text-center">
              Currently Building
            </h2>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[
                { icon: Code, title: 'Master\'s at TU Dresden', desc: 'Ecosystem Services - Preparing for global impact' },
                { icon: Leaf, title: 'EcoXchange', desc: 'Next-gen sustainability platform' },
                { icon: TrendingUp, title: 'Forex Trading Systems', desc: 'Advanced risk management strategies' },
                { icon: Globe, title: 'Crypto Research', desc: 'Exploring blockchain for environmental solutions' },
                { icon: Zap, title: 'Germany Networking', desc: 'Building tech & startup connections in Europe' },
                { icon: Code, title: 'AI & Tech Learning', desc: 'Staying ahead of the innovation curve' },
              ].map((item, idx) => {
                const Icon = item.icon;
                return (
                  <div
                    key={idx}
                    className="bg-gradient-to-br from-emerald-900/10 to-slate-900/20 border border-emerald-500/20 rounded-xl p-6 hover:border-emerald-500/40 hover:bg-emerald-900/20 transition-all duration-300 group"
                  >
                    <Icon className="w-8 h-8 text-emerald-400 mb-4 group-hover:scale-110 transition-transform" />
                    <h3 className="text-white font-bold mb-2">{item.title}</h3>
                    <p className="text-gray-400 text-sm">{item.desc}</p>
                  </div>
                );
              })}
            </div>
          </div>
        </section>

        {/* ===== SOCIAL HUB SECTION ===== */}
        <section className="min-h-screen bg-gradient-to-b from-slate-950 to-black py-20 px-6 flex items-center">
          <div className="max-w-6xl mx-auto w-full">
            <h2 className="text-5xl md:text-6xl font-black text-white mb-16 text-center">
              Connect With Me
            </h2>

            <div className="grid md:grid-cols-3 gap-6 justify-items-center">
              {[
                { icon: Linkedin, label: 'LinkedIn', link: '#', color: 'from-blue-600 to-blue-700' },
                { icon: Github, label: 'GitHub', link: '#', color: 'from-gray-700 to-gray-800' },
                { icon: Twitter, label: 'X (Twitter)', link: '#', color: 'from-black to-gray-900' },
                { icon: Instagram, label: 'Instagram', link: '#', color: 'from-pink-600 to-purple-600' },
                { icon: Mail, label: 'Email', link: 'mailto:cksivanand5@gmail.com', color: 'from-emerald-600 to-emerald-700' },
                { icon: Globe, label: 'TradingView', link: '#', color: 'from-blue-500 to-cyan-600' },
              ].map((social, idx) => {
                const Icon = social.icon;
                return (
                  <a
                    key={idx}
                    href={social.link}
                    className={`group relative w-48 h-48 rounded-2xl overflow-hidden border border-emerald-500/20 hover:border-emerald-500/60 transition-all duration-500 flex flex-col items-center justify-center cursor-pointer`}
                  >
                    {/* Gradient background */}
                    <div className={`absolute inset-0 bg-gradient-to-br ${social.color} opacity-0 group-hover:opacity-20 transition-opacity duration-500`} />
                    
                    {/* Backdrop blur */}
                    <div className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm group-hover:bg-slate-900/20 transition-all duration-500" />

                    {/* Content */}
                    <div className="relative z-10 flex flex-col items-center gap-4">
                      <Icon className="w-12 h-12 text-emerald-400 group-hover:text-emerald-300 group-hover:scale-125 transition-all duration-300" />
                      <p className="text-white font-bold text-center group-hover:text-emerald-300 transition-colors">{social.label}</p>
                    </div>

                    {/* Hover glow */}
                    <div className="absolute inset-0 bg-gradient-to-r from-emerald-500/0 via-emerald-500/0 to-emerald-500/0 group-hover:from-emerald-500/10 group-hover:via-emerald-500/20 group-hover:to-emerald-500/10 transition-all duration-500" />
                  </a>
                );
              })}
            </div>
          </div>
        </section>

        {/* ===== FUTURE VISION SECTION ===== */}
        <section className="min-h-screen bg-gradient-to-b from-black to-slate-950 py-20 px-6 flex items-center relative overflow-hidden">
          <div className="max-w-4xl mx-auto text-center relative z-10">
            <h2 className="text-6xl md:text-7xl font-black text-white mb-12 leading-tight">
              From India to Germany<br/>
              <span className="text-emerald-400">From Student to Global Founder</span>
            </h2>

            <div className="space-y-8 text-lg text-gray-300 leading-relaxed">
              <p>
                This is the story of ambition disciplined by ethics. Of wealth creation motivated by purpose.
              </p>

              <p>
                Every trade I execute teaches me discipline. Every research paper I read deepens my understanding of the natural world. Every line of code I write is a brick in the future I'm building.
              </p>

              <p>
                <span className="text-emerald-400 font-bold">EcoXchange</span> isn't just a startup. It's a proof that you can build billion-dollar companies AND restore ecosystems. That you can aim for luxury AND preserve nature.
              </p>

              <p className="text-emerald-300 font-light">
                The best time to start was yesterday. The second best time is now.
              </p>
            </div>

            {/* Call to action */}
            <div className="mt-16 flex gap-4 justify-center flex-wrap">
              <button className="px-8 py-3 bg-emerald-600 hover:bg-emerald-500 text-black font-bold rounded-lg transition-all duration-300 transform hover:scale-105">
                Let's Build Together
              </button>
              <button className="px-8 py-3 bg-transparent border-2 border-emerald-500 text-emerald-400 font-bold rounded-lg hover:bg-emerald-500/10 transition-all duration-300">
                Start a Conversation
              </button>
            </div>
          </div>
        </section>

        {/* ===== FOOTER ===== */}
        <footer className="bg-black border-t border-emerald-500/10 py-12 px-6">
          <div className="max-w-6xl mx-auto text-center">
            <p className="text-gray-500 mb-2">Sivanand C K © 2026</p>
            <p className="text-gray-600 text-sm">
              Building the future between finance, technology, and ecosystems.
            </p>
          </div>
        </footer>
      </div>

      {/* CSS Animations */}
      <style jsx>{`
        @keyframes float {
          0%, 100% { transform: translateY(0px) translateX(0px); }
          50% { transform: translateY(-20px) translateX(10px); }
        }

        @keyframes scan {
          0% { transform: translateX(-100%); }
          100% { transform: translateX(100%); }
        }

        @keyframes rotate {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }

        @keyframes fadeInOut {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.5; }
        }

        @keyframes fadeInUp {
          from {
            opacity: 0;
            transform: translateY(20px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }

        @keyframes fade-in {
          from { opacity: 0; }
          to { opacity: 1; }
        }

        .animate-fade-in {
          animation: fade-in 1.5s ease-out;
        }

        /* Scrollbar styling */
        ::-webkit-scrollbar {
          width: 8px;
        }

        ::-webkit-scrollbar-track {
          background: rgba(0, 0, 0, 0.5);
        }

        ::-webkit-scrollbar-thumb {
          background: rgba(52, 211, 153, 0.3);
          border-radius: 4px;
        }

        ::-webkit-scrollbar-thumb:hover {
          background: rgba(52, 211, 153, 0.6);
        }
      `}</style>
    </div>
  );
}
