# Shiva Premium Brand Website

A world-class, luxury personal brand website for Sivanand C K - an ambitious ecosystem services student, forex trader, crypto trader, and founder of EcoXchange.

## 🚀 Features

- **Dark Luxury Aesthetic**: Black + emerald green color scheme with glassmorphism effects
- **Animated Hero Section**: Rotating subtitles and glowing effects
- **Trader Dashboard**: Live portfolio visualization with animated charts
- **EcoXchange Founder Section**: Startup roadmap and ecosystem visualization
- **About Me**: Personal story with cinematic animations
- **Currently Building**: Dynamic cards showing parallel projects
- **Social Hub**: Premium connection cards with hover effects
- **Future Vision**: Emotional storytelling about ambition and impact
- **Fully Responsive**: Mobile-first design that works on all devices
- **Smooth Animations**: Floating particles, rotating elements, and smooth transitions

## 🛠️ Tech Stack

- **Next.js 14**: React framework for production
- **React 18**: UI library
- **Tailwind CSS**: Utility-first CSS framework
- **Lucide React**: Beautiful icon library
- **Vercel**: Deployment platform

## 📦 Installation

### Local Development

1. Clone this repository:
```bash
git clone https://github.com/cksivanand/shiva-premium-brand.git
cd shiva-premium-brand
```

2. Install dependencies:
```bash
npm install
```

3. Run the development server:
```bash
npm run dev
```

4. Open [http://localhost:3000](http://localhost:3000) in your browser

### Production Build

```bash
npm run build
npm start
```

## 🌐 Deployment

### Deploy on Vercel (Recommended)

1. Push your code to GitHub
2. Go to [Vercel](https://vercel.com)
3. Click "Import Project"
4. Select your GitHub repository
5. Click "Deploy"

Your site will be live at `https://your-project-name.vercel.app`

### Deploy on Netlify

1. Push your code to GitHub
2. Go to [Netlify](https://netlify.com)
3. Click "New site from Git"
4. Select your GitHub repository
5. Click "Deploy site"

## 📝 Customization

### Update Personal Information

Edit `pages/index.js` to update:
- Name and subtitle
- Social links
- Portfolio value
- About me content
- Contact information

### Customize Colors

Edit `tailwind.config.js` to change the color scheme:
```js
colors: {
  emerald: {
    300: "#your-color",
    400: "#your-color",
    // etc...
  },
}
```

### Add Real Links

Replace placeholder links in the social section:
```js
{ icon: Linkedin, label: 'LinkedIn', link: 'https://linkedin.com/in/yourprofile', color: 'from-blue-600 to-blue-700' },
```

## 📄 File Structure

```
shiva-premium-brand/
├── pages/
│   └── index.js          # Main website component
├── tailwind.config.js    # Tailwind configuration
├── postcss.config.js     # PostCSS configuration
├── next.config.js        # Next.js configuration
├── package.json          # Dependencies
├── .gitignore           # Git ignore file
└── README.md            # This file
```

## 🎯 Sections

1. **Hero Section**: Name, rotating subtitles, and power statement
2. **Trader's Mindset**: Portfolio visualization and core traits
3. **EcoXchange**: Startup vision and roadmap
4. **About Me**: Personal story in segments
5. **Currently Building**: Active projects and learning areas
6. **Social Hub**: Connection cards with links
7. **Future Vision**: Cinematic storytelling about ambition
8. **Footer**: Copyright and mission statement

## 🔧 Configuration

### Environment Variables

Create a `.env.local` file if needed for future integrations:
```
NEXT_PUBLIC_SITE_URL=your-domain.com
```

## 📱 Responsive Design

- Mobile-first approach
- Optimized for all screen sizes
- Touch-friendly interactive elements
- Smooth animations on all devices

## ⚡ Performance

- Optimized images and assets
- Lazy loading for better performance
- Code splitting with Next.js
- CSS-only animations for better performance

## 📞 Support

For issues or questions, contact: cksivanand5@gmail.com

## 📄 License

This project is private and proprietary.

---

**© 2026 Sivanand C K**  
Building the future between finance, technology, and ecosystems.
